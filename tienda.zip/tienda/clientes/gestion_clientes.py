
lista_clientes = []



def agregar_cliente(nombre, apellido, edad, direccion, telefono):
    new_client = {'nombre': nombre, 'apellido': apellido, 'edad': edad, 'direccion': direccion, 'telefono': telefono}
    lista_clientes.append(new_client)
    print(f"El cliente {nombre} a sido agregado satisfactoriamente!!")


def mostrar_clientes():  # definicion para mostrar los libros disponibles o si no hay nada
    if not lista_clientes:
        print("La lista de clientes esta vacia")
    else:
        print("\n -Lista de clientes disponibles para mostrar-")
        for idx, new_client in enumerate(lista_clientes):
            print(f"{idx}. {new_client['nombre']} - {new_client['apellido']} - {new_client['edad']} - {new_client['direccion']} - {new_client['telefono']}")

