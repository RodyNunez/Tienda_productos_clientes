


almacen = []     #el append solo funcionara si le especificamos bien la variable con su diccionario creado (estando vacio)


def agregar_producto(nombre, precio):
    productos = {'nombre': nombre, 'precio': precio, 'cantidad': 1}
    almacen.append(productos)
    print(f"El producto {productos} a sido agregado satisfactoriamente")


def listar_productos():  # definicion para mostrar los libros disponibles o si no hay nada
    if not almacen:
        print("El almacen de productos está vacío.")
    else:
        print("\n --- ALMACEN DE PRODUCTOS DISPONIBLES ---")
        for idx, productos in enumerate(almacen, 1):
            print(f"{idx}. {productos['nombre']} - {productos['precio']} - cantidad: {productos['cantidad']}")



