from productos.gestion_productos import agregar_producto, listar_productos
from clientes.gestion_clientes import agregar_cliente, mostrar_clientes


def menu_inicial():
    while True:
        print("\n --- Menu principal --- ")
        print("1. GESTIONAR PRODUCTOS")
        print("2. GESTIONAR CLIENTES")
        print("3. SALIR")

        seleccion = input("Seleccione una accion: ")

        if seleccion == '1':
            menu_productos()
        elif seleccion == '2':
            menu_clientes()
        elif seleccion == '3':
            break


def menu_productos():
    while True:
        print('\n --- Menu de gestion de productos ---')
        print('1- Agregar producto')
        print('2- Listar Productos')
        print('3- Volver')
        
        seleccion = input("Que desea hacer?: ")

        if seleccion == '1':
            nombre = str(input("Ingrese el nombre del nuevo producto: "))
            precio = float(input("Ingrese el precio que tendra el producto: "))
            agregar_producto(nombre, precio)

        elif seleccion == '2':
            listar_productos()
        elif seleccion == '3':
            menu_inicial()


def menu_clientes():
    while True:
        print('\n --- Menu de gestion de clientes ---')
        print('1- Agregar un cliente')
        print('2- Listar los clientes')
        print('3- Volver')

        seleccion = input("Que desea hacer?: ")

        if seleccion == '1':
            nombre = str(input("Ingrese el nombre del nuevo cliente: "))
            apellido = str(input("Ingrese el apellido del nuevo cliente: "))
            edad = str(input("Ingrese la edad del nuevo cliente: "))
            direccion = str(input("Ingrese la direccion del nuevo cliente: "))
            telefono = str(input("Ingrese el numero de telefono del nuevo cliente: "))
            agregar_cliente(nombre, apellido, edad, direccion, telefono)
        elif seleccion == '2':
            mostrar_clientes()
        elif seleccion == '3':
            menu_inicial
            

menu_inicial()




        
